from finite_audit import *
ks,t=original_rows(1);a=contract(1,ks[2192:],t[2192:]);checks={}
for suffix in ['', '_alt']:
 p=load('return081/contract'+suffix+'.json')['blocks'][1];checks[suffix or 'generator']={k:check(export(v),p[k]) for k,v in a.items()}
r={'parity':1,'start':2192,'end':8111,'checks':checks};print(json.dumps(r),flush=True);(here/'last_odd.json').write_text(json.dumps({'record':r,'bank':{k:export(v).tolist() for k,v in a.items()}},separators=(',',':'))+'\n')
