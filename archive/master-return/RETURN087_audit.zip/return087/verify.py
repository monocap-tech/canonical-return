"""Recheck saved matrices against parent intervals and immutable manifest."""
from finite_audit import *
manifest=json.loads((here/'archive_manifest.json').read_bytes())
assert len(manifest)==383 and all(sha(root/p)==h for p,h in manifest.items())
# Exercise signs and more than three limbs against Python exact dot.
a=np.array([[2**80+1,-2**64+9,0],[2**62-1,7,-2**79],[0,-2**54,1]],dtype=object)
b=np.array([[7,-2**75],[2**69,3],[-5,2**79]],dtype=object)
assert np.array_equal(dot(a,b),a.T@b)
actual=json.loads((here/'finite_audit.json').read_bytes());bank=json.loads((here/'finite_bank.json').read_bytes())
assert actual['scale']==bank['scale']==O and len(actual['banks'])==len(bank['banks'])==6
counts={'finite':0,'feature':0};checks=[]
def compare(a,b,key,group):
 a=np.array(a,dtype=object);r=check(a,b);assert r['contained']==r['entries'],(key,r);counts[group]+=r['entries'];return r
for record,d in zip(actual['banks'],bank['banks']):
 par=d['parity'];end=d['end'];assert (par,end)==(record['parity'],record['end']);r={}
 for suffix in ['', '_alt']:
  if end==1680:
   if suffix:continue
   p=load(f'return071/RETURN071_contract{par}.json')['variant'];tests={k:(d['cumulative'][k],p[k]) for k in ('tt','U')}
  elif end==2192:
   p=load('return079/RETURN079_contract'+suffix+'.json');tests={k:(d['cumulative'][k],p['blocks'][par]['finite'][k]) for k in ('tt','U')};tests.update({'increment_'+k:(d['increment'][k],p['blocks'][par]['increment'][k]) for k in ('tt','U')})
   if par:tests['restoration_cross']=(d['cumulative']['restoration_cross'],p['restoration_cross'])
  else:
   p=load('return081/contract'+suffix+'.json')['blocks'][par];tests={k:(a,p[k]) for k,a in d['increment'].items()}
  r[suffix or 'generator']={k:compare(a,b,k,'finite') for k,(a,b) in tests.items()}
 assert r==record['checks'];checks.append(record)
for par in (0,1):
 d=json.loads((here/f'band_{par}.json').read_bytes());r={}
 for suffix in ['', '_alt']:
  p=load('return080/band'+suffix+'.json')['blocks'][par];r[suffix or 'generator']={k:compare(a,p[k],k,'feature') for k,a in d['bank'].items()}
 assert r==d['record']['checks'];checks.append(d['record'])
# Frequency partition and count: the two blocks are disjoint and complete up to 32768.
ids,t=original_rows(0);f=load('return080/features.json');allks=ids+f['ks'];assert allks==sorted(list(good)+[32768]) and len(allks)==16303
out={'status':'PASS','archive_manifest_entries':len(manifest),'finite_rows_per_parity':len(ids),'feature_rows_per_parity':len(f['ks']),'total_containment_checks':sum(counts.values()),'checks_by_bank':counts,'limb_exact_product_test':'PASS','pins':{p:sha(here/p) for p in ['finite_audit.py','band_audit.py','finite_audit.json','finite_bank.json','band_0.json','band_1.json','archive_manifest.json']}}
(here/'verify.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
