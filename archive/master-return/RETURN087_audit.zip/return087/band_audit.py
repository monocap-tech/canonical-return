from finite_audit import *
f=load('return080/features.json');mom=load('return066/RETURN066_moments.json');ks=f['ks'];assert ks==list(range(16386,32769,2));good[32768]=150000

def toscale(a):return interval_array(a[...,0]//(4*S),ceildiv(a[...,1],4*S))
def mm(a,b):return toscale(product(a.transpose(1,0,2),b))
# fixed scale correlated moment matrix, independent from parent interval matrix contraction
for par in (0,1):
 t=quant(f['X'][par],f['S']);m=mom['blocks'][par]['cutoffs'][0];C=np.array(raw['blocks'][par]['C'],dtype=object);pos=np.maximum(C,0);neg=np.minimum(C,0);V=[]
 for n in range(12):
  for j in range(3):
   z=np.array(m['raw_moments'][n][j],dtype=object);lo=z[:,0]@pos+z[:,1]@neg;hi=z[:,1]@pos+z[:,0]@neg;den=mom['S']*raw['T']*f['scales'][par][3*n+j];V.append(quant(interval_array(lo*4**n,hi*4**n),den))
 V=np.array(V,dtype=object);assert V.shape==(36,87,2)
 out={n:np.zeros((d,36,2),dtype=object) for n,d in [('tt',36),('U',518+par)]+([('restoration_cross',8)] if par else [])}
 for i in range(0,len(ks),64):
  ids=ks[i:i+64];x=t[i:i+64];y=weighted(x,ids);a=aux(par,ids)
  for key,b in [('tt',x),('U',a)]+([('restoration_cross',restore(ids))] if par else []):out[key]+=product(b,y)
  if (i+64)%2048==0: print('band',par,i+64,flush=True)
 out={k:toscale(v) for k,v in out.items()};z={k:mm(v,V) for k,v in out.items()};z['tt']=mm(V.transpose(1,0,2),z['tt']);ex={k:interval_array(v[...,0]*O//S,ceildiv(v[...,1]*O,S)) for k,v in z.items()}
 checks={}
 for suffix in ['', '_alt']:
  p=load('return080/band'+suffix+'.json')['blocks'][par];checks[suffix or 'generator']={k:check(v,p[k]) for k,v in ex.items()}
 rec={'parity':par,'checks':checks};print(json.dumps(rec),flush=True);(here/f'band_{par}.json').write_text(json.dumps({'record':rec,'bank':{k:v.tolist() for k,v in ex.items()}},separators=(',',':'))+'\n')
