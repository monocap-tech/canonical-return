"""Independent fixed-scale finite-source contraction audit. No parent imports."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,json,hashlib,zipfile,time
from pathlib import Path
from fractions import Fraction as F
import numpy as np
here=Path(__file__).resolve().parent; root=Path(sys.argv[1]) if len(sys.argv)>1 else here/'work'
S=10**16;O=10**12;D=10**55;BASE=2**23
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads((root/p).read_bytes())
def ceildiv(a,b):return -((-a)//b)
def interval_array(lo,hi):return np.stack([lo,hi],axis=-1)
def quant(x,s):
 a=np.array(x,dtype=object);return interval_array(a[...,0]*S//s,ceildiv(a[...,1]*S,s))
# Signed digit splitting. Each binary64 multiplication and all partial sums exact:
# at most 64*(2^23-1)^2<2^52, including absolute sums of mixed signs.
def digits(a):
 sign=np.where(a<0,-1,1);a=abs(a);out=[]
 while np.any(a):
  out.append(((a%BASE)*sign).astype(np.float64));a=a//BASE
 return out

def dot(a,b):
 assert a.shape[0]==b.shape[0] and len(a)<=64
 aa,bb=digits(a),digits(b)
 z=np.zeros((a.shape[1],b.shape[1]),dtype=object)
 if not aa or not bb:return z
 limbs=[np.zeros(z.shape,dtype=np.int64) for _ in range(len(aa)+len(bb)-1)]
 for i,x in enumerate(aa):
  for j,y in enumerate(bb):
   p=x.T@y;assert np.all(abs(p)<2**52) and np.all(p==np.trunc(p));limbs[i+j]+=p.astype(np.int64)
 for i,v in enumerate(limbs):z+=v.astype(object)*BASE**i
 return z

def product(x,y):
 # doubled midpoint and radius; avoid integer midpoint truncation
 m=x[...,0]+x[...,1];r=x[...,1]-x[...,0];n=y[...,0]+y[...,1];s=y[...,1]-y[...,0]
 assert np.all(r>=0) and np.all(s>=0)
 v=dot(m,n);e=dot(abs(m),s)+dot(r,abs(n))+dot(r,s)
 return interval_array(v-e,v+e) # denominator 4*S*S

w=load('return047/RETURN047_payment_receipt.json');good={k:v for k,v in w['positive_even_weights'] if k>116}
cr=load('return063/RETURN063_constraints_receipt.json');iv=load('return063/RETURN063_inverse_receipt.json');raw=load('return059/RETURN059_raw_receipt.json');cbank=load('return062/RETURN062_bank_receipt.json');c0=list(map(F,cbank['c']));Q=10**42;c=(F(c0[0].numerator*Q//c0[0].denominator,Q),F(ceildiv(c0[1].numerator*Q,c0[1].denominator),Q))
pr=load('return077/proposal.json');B=np.array(pr['rows'],dtype=object);js=np.array(pr['js'],dtype=object);assert all(sum(row)==0 for row in B)

def aux(par,ks):
 k=np.array(ks,dtype=object);cb=cr['blocks'][par];ib=iv['blocks'][par];cs=cb['nodes'];Z=np.array(cb['Z'],dtype=object);l=h=k**par*116**(1-par)*D;ls=[];hs=[]
 for j in cs:
  # positive denominators for constraint nodes; independent exact interval recurrence
  a,b=(-c[1],-c[0]) if j=='sinh' else (F(j*j),F(j*j))
  assert all(k*k>a) and all(k*k>b)
  l=l*a.denominator//(k*k*a.denominator-a.numerator);h=ceildiv(h*b.denominator,k*k*b.denominator-b.numerator);ls.append(l);hs.append(h);l=l*116**2;h=h*116**2
 l=np.array(ls,dtype=object).T;h=np.array(hs,dtype=object).T;zp=np.maximum(Z,0);zn=np.minimum(Z,0);den=D*cb['Zscale'];a=(l@zp.T+h@zn.T)*S//den;b=ceildiv((h@zp.T+l@zn.T)*S,den)
 j=np.array(ib['nodes'][len(cs):],dtype=object);v=[F(ib['scales'][str(i)]) for i in j];num=S*np.array([x.numerator for x in v],dtype=object)[None,:]*(k[:,None] if par else j[None,:]);den=(k[:,None]**2-j[None,:]**2)*np.array([x.denominator for x in v],dtype=object)[None,:];assert np.all(den!=0)
 return interval_array(np.concatenate([a,num//den],axis=1),np.concatenate([b,ceildiv(num,den)],axis=1))

def restore(ks):
 k=np.array(ks,dtype=object)[:,None];den=k*k-js[None,:]**2;assert np.all(den!=0);out=[]
 for row in B:
  num=k*row[None,:]*(D//pr['scale']);out.append((np.sum(num//den,axis=1),np.sum(ceildiv(num,den),axis=1)))
 a=np.array(out,dtype=object).transpose(2,0,1);return interval_array(a[...,0]*S//D,ceildiv(a[...,1]*S,D))

def weighted(x,ks):
 d=np.array([198000+good[k] for k in ks],dtype=object)[:,None];return interval_array(x[...,0]*2000000//d,ceildiv(x[...,1]*2000000,d))

def original_rows(par):
 a=load('return062/RETURN062_mixed_receipt.json');ks=a['ks'][:];parts=[quant(a['blocks'][par]['t'],a['scale'])];C=np.array(raw['blocks'][par]['C'],dtype=object);pos=np.maximum(C,0);neg=np.minimum(C,0)
 for path,key in [('return064/RETURN064_source_receipt.json','new'),('return065/RETURN065_source_receipt.json','ks'),('return067/RETURN067_source_receipt.json','ks')]:
  a=load(path);ids=a[key];z=np.array(a['blocks'][par]['R'],dtype=object);lo=z[...,0]@pos+z[...,1]@neg;hi=z[...,1]@pos+z[...,0]@neg;sg=np.array([(-1)**(k//2) for k in ids],dtype=object)[:,None];lo,hi=np.where(sg==1,lo,-hi),np.where(sg==1,hi,-lo);parts.append(quant(interval_array(lo,hi),a['S']*raw['T']));ks+=ids
 for path in ['return068/RETURN068_rows.json','return069/RETURN069_rows.json','return071/RETURN071_rows.json','return079/RETURN079_rows.json']+[f'return081/rows_{i:02}.json' for i in range(24)]:
  a=load(path);ks+=a['ks'];parts.append(quant(a['blocks'][par],a['scale']))
 assert ks==sorted(good)[:8111] and len(ks)==8111
 return ks,np.concatenate(parts)

def contract(par,ks,t):
 out={n:np.zeros((m,87,2),dtype=object) for n,m in [('tt',87),('U',518+par)]+([('restoration_cross',8)] if par else [])}
 for i in range(0,len(ks),64):
  ids=ks[i:i+64];x=t[i:i+len(ids)];y=weighted(x,ids);a=aux(par,ids)
  for key,b in [('tt',x),('U',a)]+([('restoration_cross',restore(ids))] if par else []):out[key]+=product(b,y)
 return out

def export(a):return interval_array(a[...,0]*O//(4*S*S),ceildiv(a[...,1]*O,4*S*S))
def check(a,b):
 b=np.array(b,dtype=object);assert a.shape==b.shape
 inside=(b[...,0]<=a[...,0])&(a[...,1]<=b[...,1]);overlap=(a[...,0]<=b[...,1])&(b[...,0]<=a[...,1]);return {'entries':inside.size,'contained':int(inside.sum()),'overlap':int(overlap.sum()),'max_width_units':int(np.max(a[...,1]-a[...,0])),'max_excess_units':int(max(0,np.max(b[...,0]-a[...,0]),np.max(a[...,1]-b[...,1])))}

def main():
 result={'scale':O,'input_scale':S,'banks':[]};outbanks=[]
 for par in (0,1):
  ks,t=original_rows(par);total=None;records=[]
  for start,end in [(0,1680),(1680,2192),(2192,8111)]:
   a=contract(par,ks[start:end],t[start:end]);total=a if total is None else {k:total[k]+a[k] for k in a};p='return079/RETURN079_contract';q='return081/contract';checks={}
   for suffix in ['','_alt']:
    if end==1680:
     parent=load(f'return071/RETURN071_contract{par}.json')['variant'];
     if suffix:continue
     tests={key:(total[key],parent[key]) for key in ['tt','U']}
    elif end==2192:
     parent=load(p+suffix+'.json');tests={key:(total[key],parent['blocks'][par]['finite'][key]) for key in ['tt','U']};tests.update({'increment_'+key:(a[key],parent['blocks'][par]['increment'][key]) for key in ['tt','U']});
     if par:tests['restoration_cross']=(total['restoration_cross'],parent['restoration_cross'])
    else:
     parent=load(q+suffix+'.json')['blocks'][par];tests={key:(a[key],parent[key]) for key in a}
    checks[suffix or 'generator']={k:check(export(x),y) for k,(x,y) in tests.items()}
   rec={'parity':par,'start':start,'end':end,'checks':checks};records.append(rec);print(json.dumps(rec),flush=True)
   outbanks.append({'parity':par,'start':start,'end':end,'increment':{k:export(v).tolist() for k,v in a.items()},'cumulative':{k:export(v).tolist() for k,v in total.items()}})
   (here/f'checkpoint_{par}_{end}.json').write_text(json.dumps({'record':rec,'bank':outbanks[-1]},separators=(',',':'))+'\n')
  result['banks']+=records
 (here/'finite_audit.json').write_text(json.dumps(result,indent=2)+'\n');(here/'finite_bank.json').write_text(json.dumps({'scale':O,'banks':outbanks},separators=(',',':'))+'\n')
 print('complete',flush=True)
if __name__=='__main__':main()
