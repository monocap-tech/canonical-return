# MASTER-RETURN-084 — Freeze and structural/analytical attachment audit

## Scope and result

The RETURN-083 bounded-support gate is preserved. This pass independently derives the periodic comparison, form-domain attachment, normalization, retained-space partition and final Schur implication, and replays selected exact arithmetic obligations. It does not independently regenerate the complete directed transcendental matrix bank or audit every compressed-source and asymptotic-error lemma. Accordingly, the theorem remains conditional on those inherited enclosures and analytical lemmas. This is not Lean certification or unrestricted Weil positivity.

## 1. Custody

The original RETURN083_reproduction.zip SHA-256 is `0b129da49e5fdf1e07edcae6ebc284c616d32a5eac59545e0c2aa548940d5636`. All 383 entries pass ZIP CRC and each matches its working copy byte-for-byte. No missing or changed members. The per-file SHA-256 manifest is `archive_manifest.json`. The original archive is not modified. Reran RETURN046 independent periodic replay, RETURN059 independent original retained Gram replay, and RETURN083 terminal parity verifier; all passed. These are selected replays, not a rerun of every historical numerical program. No new mixed-source rows. The new `audit.py` verifies the archive, structural partition, Bernoulli coefficient and final rational lower-bound arithmetic. `weights.py` independently reconstructs the certified weight inequalities using the RETURN046 alternate fixed-point symbol routines, rather than the original generator.

## 2. Original supported form and periodic attachment

Use I=[-5/4,5/4], D=5/2, L=5, zero extension, and Fourier transform F(r)=integral f(x) exp(-irx) dx. Define g(r)=Re psi(1/4+ir/2)-log pi and W on the log-form domain, i.e. the supported L2 functions with integral log(2+|r|)|F(r)|² finite. The original quadratic form is

W(f) = (1/(2pi)) integral g(r)|F(r)|² dr - sum_{log n<D} w_n <(T_log n+T_-log n)f,f> + 2|c(f)|²-2|s(f)|²,

where c,s are the integrals against cosh(x/2),sinh(x/2), w_n=Lambda(n)/sqrt(n), and translations act on the zero extension. For smooth compact support, the usual Weil explicit formula with h=f*tilde f yields this expression: h(log n)+h(-log n) gives the signed prime pairing and the two pole evaluations give 2 Re[(c+s) conjugate(c-s)]=2|c|²-2|s|². This audit takes that classical explicit formula as input; no new contour proof or independent zero-sum convergence proof is claimed.

Let beta_m=2m+1/2. Digamma partial fractions give

g(r)=g(0)+sum_{m>=0} 2r²/[beta_m(beta_m²+r²)].

Each summand is the Fourier multiplier of 2I/beta_m minus convolution by exp(-beta_m|x|). In period L, its eigenvalue at r_k=2pi k/L is the same multiplier. For |x-y|<=D<L, the difference between the periodized and original exponential kernels is exactly

2 cosh(beta_m(x-y))/(exp(beta_m L)-1).

Therefore the original quadratic form equals the periodic diagonal symbol form plus

sum_m 2(|c_beta_m(f)|²-|s_beta_m(f)|²)/(exp(beta_m L)-1) +2|c(f)|²-2|s(f)|²,

where c_beta and s_beta are integrals against cosh(beta x),sinh(beta x). The sign is positive for the image cosh term because the Gamma multiplier contains the negative exponential convolution. At m=0, the negative image and pole coefficient is 2+2/(exp(L/2)-1)<11/5, and this term vanishes on the complementary sinh-null space (also on even functions). For m>=1, ||sinh(beta x)||²<=exp(beta D)/(4 beta); the negative image tail is bounded by

exp(-5(L-D)/2)/[5(1-exp(-5L/2))(1-exp(-2(L-D)))] < 1/1000.

The same exponential estimate with a larger constant bounds the sum of absolute image operator norms. The m>=1 terms converge in operator norm, with the finite m=0 term harmless. Apply the finite Gamma resolvent identity first, and then monotone convergence to the nonnegative multipliers after removing g(0). This proves equality of the original and periodic Gamma form domains on supported functions, not merely agreement on smooth probes. Prime translations have no periodic wrap interaction since every log n<D and L-log n>D; both orientations agree with zero-extension pairings. The prime powers are exactly 2,3,4,5,7,8,9,11. Thus periodic comparison is attached to the original supported log-form domain.

## 3. Independent Gamma lower and source formula derivations

For y=|r|/2, a=1/4, the summand (a+t)/((a+t)²+y²) is nonnegative and unimodal. Its total variation on the half line is at most 1/y. Comparing the sum at integer t with the integral on unit cells and taking the harmonic-number limit in the digamma series gives

Re psi(a+iy) >= (1/2)log(a²+y²)-1/y.

Hence g(r)>=log|r|-log(2pi)-2/|r| > log|r|-37/20-2/|r|. The rational log and pi check is included in weights.py. The special value g(0)=-gamma-pi/2-3log2-log pi>-6 follows from reflection/duplication and gamma<1; monotonicity in |r| follows from the positive resolvent series. For the stronger finite symbol bound, the omitted resolvent summand 2r²/[beta(beta²+r²)] decreases in beta, so the stride-two tail from beta=64.5 is at least (1/2)log(1+r²/64.5²). The independent harmonic-sum bound certifies g(0)>-5.373. The derivative used by the later model is g'(r)=sum_m 4r beta_m/(beta_m²+r²)². Comparison with the half-line integral of the unimodal summand (stride two) yields |g'(r)-1/r|<=8/r². The corresponding integral is 1/r; the variation bound follows from the maximum at beta=r/sqrt(3), and is smaller than 8/r². The decreasing resolvent sum r² sum_{m>=1}(beta_m²+r²)^-1 lies between the half-density integral starting at 2.5 and that starting at 0.5, so differs from pi*r/4 by at most 5/4. The absolute exponentially weighted sums are bounded by geometric series. These verify the basic analytical scalar estimates used downstream, not every combination of their error bounds.

For the retained exponential functions e^{ux}, the first (beta=1/2) convolution can be computed as the two triangular integrals, including the resonant denominator by its integral limit. For beta>=5/2, the exact restricted convolution is

T_beta e^{ux} = 2 beta e^{ux}/(beta²-u²) - e^{-beta(x+a)}e^{-ua}/(beta+u) - e^{-beta(a-x)}e^{ua}/(beta-u), a=5/4.

Pair with e^{vx} bilinearly and sum. Writing I(z)=integral_I exp(zx) dx, the two boundary terms yield e^{-a(u+v)}(1-exp(-D(beta-v)))/((beta+u)(beta-v)) and e^{a(u+v)}(1-exp(-D(beta+v)))/((beta-u)(beta+v)). This recovers the `ss` and `dec` terms of RETURN048, while the mass coefficient is g(0)+[psi((5/2+u)/2)+psi((5/2-u)/2)]/2-psi(5/4)+4. The prime pair equals w_n(exp((v-u)log(n)/2)+exp((u-v)log(n)/2)) times the integral of exp((u+v)x) on the symmetric overlap interval of length D-log n. The pole pair equals I(u+1/2)I(v-1/2)+I(u-1/2)I(v+1/2). Thus the raw evaluator's bilinear sign and normalization are consistent with the original form. Cosine/sine linear combinations recover the real symmetric blocks, whose complexification is the original Hermitian form.

For the digamma/trigamma primitives in RETURN048, Euler–Maclaurin on the shifted half-line reciprocal sums with p=24 and Re(w)>=64 bounds the remainders by |B_48|/(48*64^48) and |B_48|/64^49, respectively, via the periodic Bernoulli bound |B_48({t})|<=|B_48| and integral of the absolute derivative. Independently reconstructed B_48 by the Bernoulli recurrence. This establishes the stated remainder *formula*, not an independent directed implementation of every mpmath primitive. The exponentially decaying divided differences have product denominators with modulus at least beta-1/2, giving the stated geometric omitted-tail bound. Full later row regrouping, normalized-source interval regeneration, model remainder and phase integration audit remain distinct obligations.

## 4. Complementary chart and energy normalization

For periodic normalized coefficient f_k=L^-1/2 integral_I f exp(-ir_k x), each of the even and odd k grids is a complete orthonormal exponential basis of I after replacing L^-1/2 by D^-1/2. Thus each grid's periodic coefficient square sum is (1/2)||f||². After splitting into real parity and using normalized cos/sin on the positive even grid, the pair of periodic coefficients contributes one-half of the squared physical coordinate. The even-grid diagonal surplus above .1 contributes w_k/2, and the odd-grid surplus contributes one-half its corresponding physical coefficient squared. These factors account for A=.099+w_k/2 and for the restored positive/negative row coefficients 8v_j/pi² and 8d_j/pi². Indeed the rephased normalized trig overlaps on positive odd j and positive even k are 4j/[pi(k²-j²)] in the even sector and 4k/[pi(k²-j²)] in the odd sector, up to row/column signs. This follows by integrating the product of trigonometric functions on I. The odd sinh-null constraint is proportional to the rephased row k/(k²+25/(16pi²)), by integrating sinh(x/2)sin(r_k x). The row normalization or rational-product change of basis preserves its kernel. The raw cosine/sine mass is 5/4, so the raw mixed source's squared inverse normalization is 4/5, as used throughout the certificates.

The retained span P consists of 38 even exceptional indices including zero in the even parity, 37 positive even exceptional indices plus the sinh function in the odd parity, five unpaid positive odd indices per parity and the first 44 good positive even indices through 116. Hence 87 independent functions per parity, 174 total. Independence follows from distinct exponential exponents (including the two real exponents of sinh), or from the positive retained Gram. Q=P-perp in physical L2 has exactly the retained-annihilation constraints, and its rephased even coordinates are all good even k>116, subject to the five unpaid odd constraints and, in odd parity, sinh. Exact index checks give 16302 finite coordinates below 32768 and the boundary 32768, hence 16303 coordinates through that boundary. The archive partition includes 2192+5919 actual rows and 8192 modeled rows there. All high bands have disjoint endpoints. This is a model coverage statement, not a claim of exact pointwise source evaluation in compressed bands.

The independent fixed-point replay checks 16346 base good even weights, 36 upgraded even weights, 481 restored positive odd weights, 35 paid odd deficits, and 500 additional positive odd restoration weights. The 36 upgraded even weights lie entirely in P. The 500 restoration indices are distinct, disjoint from earlier positive and exceptional odd rows, and all eight frozen coefficient rows have exact zero sum. The shared positive cost bounds the restored form by the original unused positive energy (weighted projection/Cauchy-Schwarz); no double allocation. Infinite-band lower symbol bounds at k=32768,65536,262144 independently exceed .25,.94,2.3, respectively. The periodic lower form on Q is .099I plus positive even and odd surplus, minus paid odd deficits. In normalized coordinates it is A+F*F-G*G, on the inherited constraints. The pinned RETURN062 negative-update bounds are each <.52. Thus the comparator is bounded below by .48A>=.04752I. Further positive restoration and larger diagonal preserve this floor. This audit reuses rather than independently recomputes the RETURN062 infinite negative Gram and RETURN083 full augmented inverse. The old and new lower forms are legitimate on the original complementary form domain, not on a substituted physical space.

## 5. Form-domain and Schur transfer, including a quantitative endpoint

Every retained truncated exponential is bounded and piecewise smooth, with Fourier transform O((1+|r|)^-1). Since g(r)=O(log(2+|r|)), it lies not just in the Gamma form domain but in the multiplier operator domain. Consequently the mixed functional W(p,q) is an L2-continuous functional of q for each retained p, by Plancherel and bounded prime/pole terms. This justifies identifying it with its actual normalized even-grid row sequence, without assuming that finite Fourier sums converge in the log-form norm. Orthogonal projection onto P preserves the form domain (subtract a finite retained combination). Thus f=p+q is the genuine physical L2 orthogonal splitting of every supported form-domain element. Complexification follows from real symmetric form, and reflection invariance gives zero even/odd cross term.

For a positive bounded complementary comparator D on the constraint kernel, the signed saddle identity follows by solving K y=L A^-1 t with K=L A^-1 L*+J. Then q=A^-1(t-L*y), constraint rows force q into the kernel and signed rows give the original comparator equation; hence <t,D^-1 t>=<t,A^-1 t>-<U,K^-1 U>. Including the shared restoration is the same calculation with extra positive ridge. The trial residual identity is exact for symmetric invertible K, regardless of its signature. Upper bounds on the true normalized dual payment therefore imply |W(p,q)|²<=alpha H(p) D(q). With original Q energy >=D(q),

W(p+q) >= H(p)+D(q)-2 sqrt(alpha) sqrt(H(p)D(q)) >= (1-sqrt(alpha))(H(p)+D(q)).

Use the pinned RETURN081 and RETURN083 explicit true-source upper bounds .990269785129 and .955551215529, respectively. Exact rational checks show their square roots are smaller than .996 and .978. The RETURN059 retained physical floors are >4.5304e-57 even and >3.9523e-53 odd. This is obtained by positive rational congruence and the raw chart mass bound D*87; congruence injectivity follows from strict positivity of the square congruenced matrix. Combined with D>=.04752I and orthogonality of p,q, this gives the explicit, conservative conditional inequalities

W(f_even) >= 1e-59 ||f_even||²,
W(f_odd) >= 1e-55 ||f_odd||²,
W(f) >= 1e-59 ||f||²

on the diameter-2.5 supported log-form domain. Translation invariance gives the same statement for any translated interval of that diameter. This is a derived lower bound, not a numerical approximation to the smallest eigenvalue; its smallness reflects the frozen chart conditioning. No support enlargement or global implication has been certified.

## 6. Remaining audit work

The new derivations secure the structural receiver and several analytical primitives. The complete result is still conditional on inherited arithmetic source enclosures, all exact row-model error estimates (RETURN066, RETURN072, RETURN080), weighted phase/cross aggregation and the terminal full inverse-payment enclosures. These have previous generator/alternate replays, not a comprehensive independent regeneration here. The standard explicit formula was taken as input. No new external zero-height input; no formal theorem in Lean, no adoption of active proof head, no arbitrary-support transfer or RH. Next audit the complete mixed-source attachment and error transfer in dependency order, using the fixed archive as the sole reference; only then choose a principled global-support investigation. The attached NF662 transfer note concerns a separate 15-generator formalization, not a Lean certificate of this 174-dimensional computation.
