from fractions import Fraction as F
from pathlib import Path
import json,hashlib
h=Path(__file__).resolve().parent;r=h.parent
p=r/'return046/return046_replay.py';ns={'__file__':str(p)};exec(p.read_text().split('bad=set(')[0],ns)
S=ns['S'];pl,pu=F(ns['pl'],S),F(ns['pu'],S);lb=ns['log_bounds'];n=4096
Hup=F(sum(-(-S//i)for i in range(1,n+1)),S);assert -(Hup-lb(n)[0])-pu/2-3*lb(2)[1]-lb(pu)[1]>F(-5373,1000)
assert lb(2*pu)[1]<F(37,20) and 1+pu/2+3*lb(2)[1]+lb(pu)[1]<6
load=lambda p:json.loads((r/p).read_bytes())
w=load('return047/RETURN047_payment_receipt.json');up=load('return057/RETURN057_weights.json');v=load('return075/RETURN075_receipt.json')['weights'];pr=load('return077/proposal.json');assert {j for j,_ in v}==set(pr['js'])
base=lambda k:F(ns['glo'](k)-ns['pupper'](k),S)-F(1,10)
for k,d in w['positive_even_weights']:assert base(k)>=F(d,10**6)
for k,d in v:assert base(k)>=F(d,10**6)>0
# Improved positive resolvent series: the decreasing tail has a lower integral.
def improved(k):
 x=(2*pl*k/5)**2;g=F(-5373,1000);B=F(129,2)
 for j in range(32):
  b=F(4*j+1,2);t=2*x/(b*(b*b+x));g+=F(t.numerator*S//t.denominator,S)
 g+=lb(1+x/B**2)[0]/2
 return max(g,F(ns['glo'](k),S))-F(ns['pupper'](k),S)-F(1,10)
for k,d in up['even']+up['odd_good']:assert improved(k)>=F(d,10**6)
for k,d in up['odd_deficit']:assert improved(k)>=-F(d,10**6)
# independent global prime triangle and monotone gamma lower for infinite bands
caps={}
for k,A in [(32768,F('.174')),(65536,F('.519')),(262144,F('1.199'))]:
 z=F(ns['glo'](k)-ns['tri'],S);assert z>F('.1')+2*(A-F('.099'));caps[str(k)]=str(z)
out={'status':'PASS','base_even_weights':len(w['positive_even_weights']),'upgraded_even_weights':len(up['even']),'restored_odd_weights':len(up['odd_good']),'paid_odd_deficits':len(up['odd_deficit']),'additional_restoration_weights':len(v),'tail_lower':caps};(h/'weights.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS independent weights',out)
