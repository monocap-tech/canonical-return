#!/usr/bin/env python3
"""Independent structural/custody checks; not a transcendental source regeneration."""
from pathlib import Path
from fractions import Fraction as F
from math import comb, factorial
import hashlib,json,zipfile,sys
sys.set_int_max_str_digits(0)
h=Path(__file__).resolve().parent;r=h.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads((r/p).read_bytes())
pins={'return083/RETURN083_reproduction.zip':'0b129da49e5fdf1e07edcae6ebc284c616d32a5eac59545e0c2aa548940d5636','return083/verify.json':'94a49c4bce903a6f0e79cd3985186d10f55d5a02db86001995b124b890452c2e','return046/RETURN046_periodic_receipt.json':'34a0f40975e097c50fa7205d90715565a01972edcaf1614c9f42c4d6b7752d42','return047/RETURN047_payment_receipt.json':'def4c4d30dbd4467d9eee44e18edfefa407c349928c9fd21de4851e87650cc4f','return057/RETURN057_weights.json':'090ec051ef390b339357496b805808a846268352c43b70befb1c3ede3614a926','return059/RETURN059_raw_receipt.json':'2433554360bde233df3718c68323c5e0d007e4976eb1c5e4a8cf7b842648ded8','return081/verify.json':'7d4ba97a0ab630d1e429aa3602e4ec6efd1fe68243032ba2713fc05b6ea1e2fa'}
for p,s in pins.items():assert sha((r/p).read_bytes())==s,p
with zipfile.ZipFile(r/'return083/RETURN083_reproduction.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==383 and z.testzip() is None
 manifest={n:sha(z.read(n)) for n in z.namelist()}
 differences=[n for n,s in manifest.items() if (r/n).is_file() and sha((r/n).read_bytes())!=s]
 missing=[n for n in manifest if not (r/n).is_file()]
 print('archive live differences',differences,'missing',missing,flush=True)
 assert not differences and not missing
(h/'archive_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
per=load('return046/RETURN046_periodic_receipt.json');w=load('return047/RETURN047_payment_receipt.json');up=load('return057/RETURN057_weights.json');raw=load('return059/RETURN059_raw_receipt.json');fin=load('return083/verify.json');old=load('return081/verify.json')
bad={k for k in per['exceptional_nonnegative_indices']} ;ev={k for k in bad if k%2==0};od={k for k in bad if k%2};un={k for k in w['unpaid_odd'] if k>0};paid={k for k in w['paid_odd'] if k>0};low=set(raw['ks']);good=dict(w['positive_even_weights']);assert ev=={k for k in w['even_exceptional'] if k>=0};assert un.isdisjoint(paid) and un|paid==od
assert set(good)==set(range(0,32768,2))-ev and low=={k for k in good if k<=116} and len(low)==44
assert len(ev)==38 and len(un)==5 and len(paid)==35
assert len(ev|un|low)==87 and len((ev-{0})|un|low)+1==87
assert set(dict(up['even']))<=low and set(dict(up['odd_good'])).isdisjoint(od)
assert set(dict(up['odd_deficit']))==paid and all(v>=0 for _,v in up['odd_deficit'])
assert old['finite_coordinates']==len(set(good)-low)+1==16303 and old['unrepresented_coordinates']==0
# All 500 restoration rows disjoint from earlier paid/restored nodes.
pr=load('return077/proposal.json');js=set(pr['js']);assert len(js)==500 and min(js)>1024 and not js&od and not js&set(dict(up['odd_good']))
assert len(pr['rows'])==8 and all(len(x)==500 and sum(x)==0 for x in pr['rows'])
# Independently reconstruct Bernoulli number used for the source EM remainder.
B=[F(1)]
for n in range(1,49):B.append(-sum(comb(n+1,j)*B[j] for j in range(n))/F(n+1))
assert B[48]==-F(5609403368997817686249127547,46410)
# EM absolute error with Re(w)>=64; formula audit in companion report.
epsi=abs(B[48])/ (48*64**48);etri=abs(B[48])/64**49
# derive global explicit L2 lower from Schur relative bounds and retained physical floors
alpha=[F(old['even_explicit_triangle_upper']),F(fin['odd_explicit_triangle_upper'])]
roots=[F('.996'),F('.978')];assert all(a<b*b for a,b in zip(alpha,roots))
floors=[F(x['physical_floor']) for x in raw['blocks']];assert all(x>0 for x in floors)
neg=load('return062/RETURN062_replay_receipt.json');assert all(F(x['G_Ainv_Gt_norm_upper'])<F('.52') for x in neg['blocks'])
qfloor=F('.48')*F('.099');caps=[(1-b)*min(f,qfloor) for b,f in zip(roots,floors)]
assert caps[0]>F(1,10**59) and caps[1]>F(1,10**55)
out={'status':'PASS structural and custody audit','archive_entries':len(manifest),'manifest_sha256':sha((h/'archive_manifest.json').read_bytes()),'pins':pins,'even_exceptional_positive_including_zero':len(ev),'unpaid_odd_positive':len(un),'retained_good_even_positive':len(low),'dimension_per_parity':87,'finite_complement_coordinates_per_parity':16303,'restoration_rows':8,'restored_positive_nodes':500,'psi_EM_error_bound':str(epsi),'trigamma_EM_error_bound':str(etri),'conditional_L2_floor_even':'1e-59','conditional_L2_floor_odd':'1e-55','conditional_L2_floor_common':'1e-59','exact_parity_floor_caps':[str(x)for x in caps],'limitations':['No independent transcendental regeneration','No full audit of compressed model and asymptotic error formulas','No Lean theorem or arbitrary-support transfer']}
(h/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(manifest),'archive members and retained partition; conditional L2 floor 1e-59')
