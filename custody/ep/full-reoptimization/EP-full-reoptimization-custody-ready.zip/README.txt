EP full reoptimization and frozen-center audit

Repository parent: ffacfbe4aff437551746ab1b21532daf127cb523
Local publication package only; no repository attachment verified.
Extract this archive and verify each payload against MANIFEST.json.
Then run: python ep_frozen_center_audit.py EP-full-reoptimization-provisional.zip replay.json
The physical index upper bound remains <=205.
