from pathlib import Path
from fractions import Fraction as F
import shutil
p=Path('/mnt/data/alp076_pairs'); bank=Path('/mnt/data/alp075_final/bank'); base=Path('/mnt/data/alp074_local/cr_alp_058')
D=10**80
def fmt(x):
 z=x*D;assert z.denominator==1;n=z.numerator;return ('-' if n<0 else '')+str(abs(n)//D)+'.'+str(abs(n)%D).zfill(80)
def interval(a,b,s):
 l,h=map(F,a);ll,hh=map(F,b);assert l<=h and ll<=hh
 return [fmt(l+ll if s==1 else l-hh),fmt(h+hh if s==1 else h-ll)]
for i,j in [(12,14),(12,9)]:
 for sign in [1,-1]:
  tag=f'{i}_{j}_{"plus" if sign==1 else "minus"}';d=p/tag;d.mkdir(exist_ok=True)
  a=(bank/f'input_2_{i}.txt').read_text().splitlines();b=(bank/f'input_2_{j}.txt').read_text().splitlines();assert len(a)==len(b)
  k=0;out=[]
  def same():
   global k
   assert a[k]==b[k];out.append(a[k]);k+=1;return int(a[k-1])
  def pair():
   global k
   out.append(' '.join(interval(a[k].split(),b[k].split(),sign)));k+=1
  assert same()==2;pair();pair();n=same();assert n==425
  for _ in range(n):
   x,y=a[k].split(),b[k].split();assert x[0]==y[0] and len(x)==len(y)==5
   out.append(' '.join([x[0]]+interval(x[1:3],y[1:3],sign)+interval(x[3:5],y[3:5],sign)));k+=1
  n=same();assert n==128
  for _ in range(n):
   x,y=a[k].split(),b[k].split();assert x[:2]==y[:2] and len(x)==len(y)==4
   out.append(' '.join(x[:2]+interval(x[2:],y[2:],sign)));k+=1
  n=same();assert n==25
  for _ in range(n):
   assert a[k]==b[k];out.append(a[k]);m=int(a[k].split()[-1]);assert m==40;k+=1
   for _ in range(m):pair()
  assert k==len(a)
  (d/'input_2.txt').write_text('\n'.join(out)+'\n')
  for name in ['validate_geometry.py','gauss.txt','mesh.txt','input_1.txt']:shutil.copyfile(base/name,d/name)
