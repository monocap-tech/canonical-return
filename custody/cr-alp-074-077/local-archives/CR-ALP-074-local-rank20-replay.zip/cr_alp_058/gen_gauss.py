from fractions import Fraction as F
from math import comb,floor,ceil
import mpmath as mp
mp.mp.dps=105
N=96; co=[0]*(N+1)
for j in range(N//2+1):co[N-2*j]=(-1)**j*comb(N,j)*comb(2*N-2*j,N)
dp=[(i+1)*co[i+1] for i in range(N)]
dd=F(sum(abs(i*dp[i]) for i in range(1,N)),2**N)
def val(c,x):
 m,q=x.numerator,x.denominator;v=0;qp=1
 for a in reversed(c):v=v*m+a*qp;qp*=q
 return F(v,qp//q*2**N)
D=10**80
def dec(n):return ('-' if n<0 else '')+str(abs(n)//D)+'.'+str(abs(n)%D).zfill(80)
x,_=mp.gauss_quadrature(N,'legendre');lines=[str(N)]
for v in x:
 l=F(int(mp.floor(v*10**75)),10**75);h=l+F(1,10**75)
 assert val(co,l)*val(co,h)<0
 der=abs(val(dp,(l+h)/2));er=dd*(h-l)/2;assert der>er
 ma=max(abs(l),abs(h));mi=min(abs(l),abs(h)) if l*h>0 else F(0)
 wl=2/((1-mi**2)*(der+er)**2);wh=2/((1-ma**2)*(der-er)**2)
 lines.append(' '.join([dec(floor(l*D)),dec(ceil(h*D)),dec(floor(wl*D)),dec(ceil(wh*D))]))
open('gauss.txt','w').write('\n'.join(lines)+'\n')
