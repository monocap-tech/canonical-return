from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import hashlib,json,zipfile
P=Path(__file__).resolve().parent
BASE=P.parent
S=10**30
ell=F(51,200); u=F(1101,200); gamma=F(72,25)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def root(x):
    assert x>=0
    t=x*S*S
    return F(isqrt(t.numerator//t.denominator)+1,S)
# Authenticate original published rank-70 artifacts and prior cross replay.
archives={'CR-ALP-075-prefix-receiver.zip':'507cbaeaeb6401469e83c560c2b36198f41bd798d29f2769cf5e5607d77036ae','CR-ALP-075-source-bank.zip':'0862e7009382dc37e256651f7692068da90b03c411789d353ba6265615e1e76e'}
for n,h in archives.items():assert sha(BASE/n)==h
with zipfile.ZipFile(BASE/'CR-ALP-075-prefix-receiver.zip') as z:
    assert z.testzip() is None; data=json.loads(z.read('result.json'))
with zipfile.ZipFile(BASE/'CR-ALP-075-source-bank.zip') as z:
    assert z.testzip() is None;bank=json.loads(z.read('source_bank.json'));assert z.read('input_2_12.txt')==(P/'input_2.txt').read_bytes()
    for h,n in (l.split() for l in z.read('SHA256SUMS').decode().splitlines()):assert hashlib.sha256(z.read(n)).hexdigest()==h
with zipfile.ZipFile(BASE/'CR-ALP-076-targeted-cross-replay.zip') as z:
    assert z.testzip() is None
    for h,n in (l.split() for l in z.read('SHA256SUMS').decode().splitlines()):assert hashlib.sha256(z.read(n)).hexdigest()==h
    pair=json.loads(z.read('pairs/pair_result.json'))
    for j in (12,14,9):
        row=next(x for x in bank['entries'] if x['parity']=='2' and x['coordinate_zero_based']==j)
        assert hashlib.sha256(z.read(f'sources/input_2_{j}.txt')).hexdigest()==row['sha256']
assert data['rank']==69
c=next(x for x in bank['entries'] if x['parity']=='2' and x['coordinate_zero_based']==12)
assert sha(P/'input_2.txt')==c['sha256']
assert 'direct product quadrature and shift displacement budgets PASS' in (P/'geometry.log').read_text()
logs={a[0]:(F(a[1])/10**15,F(a[2])/10**15) for a in [l.split() for l in (P/'moment.log').read_text().splitlines()]}
assert set(logs)=={'G','M','penalty',*(f'corr{i}' for i in range(7))}
assert all(l<=h for l,h in logs.values())
G=logs['G'][1]; q=root(G)
eps=F(5,10**9)+F(c['omitted_group_midpoint_norm_upper'])+F(1,10**13)
err=eps*(2*q+eps)
Mlo=logs['M'][0]-F(21,8)*err-F(1,10**13)
Gup=G+err
A=(gamma*Gup-Mlo)/(ell*u)
bs={x['coordinate']:F(x['norm_upper']) for x in data['sectors']['2']['columns']}
assert A<F(21123060,10**9)
rows={'12':{'inverse_upper':str(A),'scalar_inverse_upper':str(bs[12]**2/ell),'rounded_upper':str(F(21123060,10**9))}}
for j,alpha,cap in [(14,F(233661,250000),F(20749603,10**9)),(9,-F(143787,200000),F(12318887,10**9))]:
    l,h=map(F,pair['pairs'][f'12,{j}']['cross_interval'])
    e2=bs[j]**2-2*alpha*(l if alpha>=0 else h)+alpha*alpha*bs[12]**2
    assert e2>=0
    v=(abs(alpha)*root(A)+root(e2/ell))**2
    assert v<cap
    rows[str(j)]={'alpha':str(alpha),'remainder_norm_upper':str(root(e2)),'relative_remainder_upper':str(root(e2)/bs[j]),'inverse_upper':str(v),'scalar_inverse_upper':str(bs[j]**2/ell),'rounded_upper':str(cap)}
ans={'status':'CONDITIONAL_THREE_COLUMN_INVERSE_BOUNDS','G_upper':str(Gup),'M_lower':str(Mlo),'proxy_error':str(eps),'columns':rows,'premises':'Original CR-ALP-057/058 proxy and quadrature bounds; inherited L spectral interval and exact source identities. Prior cross intervals reused, not regenerated here.'}
(P/'three_mode_result.json').write_text(json.dumps(ans,indent=2)+'\n')
for k,r in rows.items():print(k, float(F(r['inverse_upper'])), float(F(r['scalar_inverse_upper'])),float(F(r.get('remainder_norm_upper','0'))))
print('PASS exact rational inverse transfer')
